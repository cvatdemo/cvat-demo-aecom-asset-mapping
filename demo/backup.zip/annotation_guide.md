# Facility Asset Mapping: data and model credits

- Data: Oil Tanks (Roboflow Universe, by Liangyu Wu) (https://universe.roboflow.com/liangyu-wu/oil-tanks/dataset/4)
- Attribution: Oil Tanks dataset by Liangyu Wu, Roboflow Universe (https://universe.roboflow.com/liangyu-wu/oil-tanks), licensed CC BY 4.0.
- License: CC BY 4.0
- Pre-label model: Aerial Tanks (https://universe.roboflow.com/yamen-gm7rm/aerial-tanks/model/2). Pre-trained only; nothing was trained on these images.